package com.rance.chatui.ui.activity;


import android.os.Handler;

public interface MessageTarget {
    public Handler getHandler();
}

package com.rance.chatui.ui.fragment;

import com.rance.chatui.enity.PeerInfo;

public interface PeerClickListener {
    void chatP2p(PeerInfo peerInfo);
}

package com.rance.chatui.ui.fragment;

public interface FragmentBackHandler {
    boolean onBackPressed();
}
